# BallBoi

BallBoi - A package to fetch sports information from https://profootballapi.com